function connect($SubscriptionID)
{
  if($null -eq (Get-AzContext).Account)
  {
    Connect-AzAccount
    Set-AzContext $SubscriptionID
  }
}

function getBearer([string]$TenantID, [string]$ClientID, [string]$ClientSecret)
{
  $TokenEndpoint = {https://login.windows.net/{0}/oauth2/token} -f $TenantID
  $ARMResource = "https://management.core.windows.net/";

  $Body = @{
          'resource'= $ARMResource
          'client_id' = $ClientID
          'grant_type' = 'client_credentials'
          'client_secret' = $ClientSecret
  }

  $params = @{
      ContentType = 'application/x-www-form-urlencoded'
      Headers = @{'accept'='application/json'}
      Body = $Body
      Method = 'Post'
      URI = $TokenEndpoint
  }

  $token = Invoke-RestMethod @params

  Return "Bearer " + ($token.access_token).ToString()
}


function getLinkedService([string]$LinkedService)
{
  $ADFEndpoint = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.DataFactory/factories/$DataFactoryName/linkedservices/$($LinkedService)?api-version=2018-06-01"

  $params = @{
      ContentType = 'application/json'
      Headers = @{'accept'='application/json';'Authorization'=$BearerToken}
      Method = 'GET'
      URI = $ADFEndpoint
  }

  $a = Invoke-RestMethod @params
  Return ConvertTo-Json -InputObject @{"linkedService" = $a} -Depth 10
}


function testLinkedServiceConnection($Body)
{

  $AzureEndpoint = "https://management.azure.com/subscriptions/$SubscriptionID/resourcegroups/$ResourceGroup/providers/Microsoft.DataFactory/factories/$DataFactoryName/testConnectivity?api-version=2017-09-01-preview"

  $params = @{
      ContentType = 'application/json'
      Headers = @{'accept'='application/json';'Authorization'=$BearerToken}
      Body = $Body
      Method = 'Post'
      URI = $AzureEndpoint
  }

  Return (Invoke-RestMethod @params).succeeded
}

# These are dummy secrets!
$TenantID       = args[0]
$ClientID       = args[1]
$ClientSecret   = args[2]
$DataFactoryName = args[3]
$ResourceGroup  = args[4]
$SubscriptionID = args[5]
$lsname = args[6]
connect $SubscriptionID
$BearerToken = getBearer $TenantID $ClientID $ClientSecret

$LinkedServiceBody = getLinkedService $lsname
testLinkedServiceConnection $LinkedServiceBody