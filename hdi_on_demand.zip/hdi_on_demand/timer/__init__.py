import logging
import azure.functions as func
from azure.storage.blob import BlockBlobService
from azure.storage.blob import BlobPermissions
from azure.storage.blob import AppendBlobService
import pathlib
import os
import time
import datetime
import json
import ast
import shutil
import sys
import traceback
import deployer.deployer as deployer
import idle.idle as idle
import lockmanager.lockmanager as lockmanager



def main(req: func.HttpRequest) -> func.HttpResponse:

    #receiving information from json file sent by adf pipeline
    logging.info("starting Timer function.....")
    configurations_json = req.get_json()
    subscription_id = configurations_json['subscription_id']
    resource_group = configurations_json['resource_group']
    client_id = configurations_json['client_id']
    secret = configurations_json['secret']
    tenant = configurations_json['tenant']
    clustername = configurations_json['clustername']
    adfname = configurations_json['adfname']
    user = configurations_json['user']
    password_hdi = configurations_json['password_hdi']
    storage_account_name = configurations_json['storage_account_name']
    storage_account_key = configurations_json['storage_account_key']
    threshold_hours = configurations_json['threshold_hours']
    container = configurations_json['container']

    jsonFinal = "{\"items\":\"" + resource_group + "\"}"

    logging.info("threshold_hours :" + threshold_hours)

    timer_func(subscription_id,
               resource_group,
               client_id,
               secret,
               tenant,
               clustername,
               adfname,
               user,
               password_hdi,
               storage_account_name,
               storage_account_key,
               threshold_hours,
               container)

    #dummy response to not receive final error
    return func.HttpResponse(jsonFinal, mimetype="application/json")



def timer_func(subscription_id,
               resource_group,
               client_id,
               secret,
               tenant,
               clustername,
               adfname,
               user,
               password_hdi,
               storage_account_name,
               storage_account_key,
               threshold_hours,
               container):

    d = deployer.Deployer(subscription_id, resource_group, client_id, secret, tenant, clustername)
    timer = idle.Idle(subscription_id, resource_group, client_id, secret, tenant, clustername, adfname, user,
                      password_hdi)
    idle_time = timer.return_time()
    lm = lockmanager.Lockmanager(storage_account_name, storage_account_key, container)

    # timer.check_linked_service()
    logging.info(threshold_hours)
    #verifies if the time idle is bigger than the threshold hours defined
    #and if it doesnt currently have a lock for creation or destruction
    #if all holds true, creates the destruction lock, starts the destruction of the hdi cluster and puts the function
    #in sleep mode for 30 min to wait for the destruction to complete.
    if float(idle_time) > float(threshold_hours) and not lm.lock_found("creation") and not lm.lock_found("destruction"):
        lm.create_lock("destruction")
        logging.info("Idle time bigger than threshold, destroying cluster: " + clustername)
        d.destroy_hdi(resource_group, clustername)
        #sleep(30 min)
        time.sleep(30 * 60)
        lm.release_lock("destruction")

    logging.info("idle_time is " + idle_time)