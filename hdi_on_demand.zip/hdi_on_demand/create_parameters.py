import pathlib
import os
# import pandas as pd
import json
import ast
import shutil
import sys
import traceback

#TO-DO: create parameter files with use case name?
def create_parameters_file(filename, outputpath):
    print("creating parameters file from : " + filename + " to " + outputpath)
    outputjson = {}
    # outputjson["parameters"] = {}
    f = open(filename, "r")
    words = f.read()
    #print(words)
    splitted_json_string = words.split('{"format_version"', 1)
    jsonfile = splitted_json_string[1:]
    jsonfile.insert(0, '{"format_version"')
    info = "".join(jsonfile)
    # print(info)
    # print(jsonfile)
    # with open('json') as json_file:
    data = json.loads(info)
    for p in data["resource_changes"]:
        if p["type"] == "azurerm_template_deployment" and p["name"] == "hdi":
            for x in p["change"]["after"]["parameters"]:
                param = {"value": p["change"]["after"]["parameters"][x]}
                outputjson[x] = param
    with open(outputpath + '\parameters.json', 'w') as outfile:
        json.dump(outputjson, outfile, indent=4)
    return outfile.name

p_file = sys.argv[1]
outputpath = sys.argv[2]

create_parameters_file(p_file,outputpath)
