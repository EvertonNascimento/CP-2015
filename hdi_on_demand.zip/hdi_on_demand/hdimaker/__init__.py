import logging
import azure.functions as func
from azure.storage.blob import BlockBlobService
from azure.storage.blob import BlobPermissions
from azure.storage.blob import AppendBlobService
import pathlib
import os
import time
import datetime
# import pandas as pd
import json
import ast
import shutil
import sys
# import nokia.util as util
# import nokia.log as log
import traceback
import deployer.deployer as deployer
import idle.idle as idle
import lockmanager.lockmanager as lockmanager


def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    logging.info("starting deployer function.....")
    #receiving information from json file sent by adf pipeline

    configurations_json = req.get_json()
    subscription_id = configurations_json['subscription_id']
    resource_group = configurations_json['resource_group']
    client_id = configurations_json['client_id']
    secret = configurations_json['secret']
    tenant = configurations_json['tenant']
    clustername = configurations_json['clustername']
    adfname = configurations_json['adfname']
    user = configurations_json['user']
    password_hdi = configurations_json['password_hdi']
    storage_account_name = configurations_json['storage_account_name']
    storage_account_key = configurations_json['storage_account_key']
    threshold_hours = configurations_json['threshold_hours']
    container = configurations_json['container']
    usecase = "ndpe"

    jsonFinal = "{\"items\":\"" + usecase + "\"}"
    # jsonFinal = "{\"items\":\""+resource_group+"\"}"
    creation(subscription_id,
             resource_group,
             client_id,
             secret,
             tenant,
             clustername,
             adfname,
             user,
             password_hdi,
             storage_account_name,
             storage_account_key,
             threshold_hours,
             container)
    #remove threshold hours
    #storage account info and container irrelevant? need to test multiple runs of creation of cluster
    return func.HttpResponse(jsonFinal, mimetype="application/json")

    # verifications(threshold_hours)

def creation(subscription_id,
             resource_group,
             client_id,
             secret,
             tenant,
             clustername,
             adfname,
             user,
             password_hdi,
             storage_account_name,
             storage_account_key,
             threshold_hours,
             container):
    d = deployer.Deployer(subscription_id, resource_group, client_id, secret, tenant, clustername)
    lm = lockmanager.Lockmanager(storage_account_name, storage_account_key, container)
    timer = idle.Idle(subscription_id, resource_group, client_id, secret, tenant, clustername, adfname, user,
                      password_hdi)

    #verify if the resource group currently has a cluster and if a creation or destruction is not in process
    #if it all holds true, creates a lock for the creation of the hdi cluster, starts the deployment and puts the
    #function to sleep for 40 min to wait for the deployment to finish.
    # after the deployment is done releases the lock.
    if not d.has_hdi(resource_group, clustername) and not lm.lock_found("creation") and not lm.lock_found("destruction"):
        lm.create_lock("creation")
        d.deploy()
        timer.valid_ls()
        #wait 40 min sleeps(40min)
        #minutes * seconds in a minute
        #time.sleep(40 * 60)
        lm.release_lock("creation")
    else:
        logging.info("hdi " + clustername + "is already in " + resource_group)

    print("Done.")